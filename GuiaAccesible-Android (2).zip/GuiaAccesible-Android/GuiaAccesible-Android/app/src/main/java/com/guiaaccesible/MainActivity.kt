package com.guiaaccesible

import android.Manifest
import android.annotation.SuppressLint
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.MediaStore
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.util.Base64
import android.util.Log
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FallbackStrategy
import androidx.camera.video.FileOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.core.graphics.ColorUtils
import androidx.core.view.WindowCompat
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.net.UnknownHostException
import java.util.Locale
import java.util.concurrent.Executors

open class SimpleListener : RecognitionListener {
    override fun onReadyForSpeech(p: Bundle?) {}
    override fun onBeginningOfSpeech() {}
    override fun onRmsChanged(p: Float) {}
    override fun onBufferReceived(p: ByteArray?) {}
    override fun onEndOfSpeech() {}
    override fun onError(p: Int) {}
    override fun onResults(p: Bundle?) {}
    override fun onPartialResults(p: Bundle?) {}
    override fun onEvent(p: Int, b: Bundle?) {}
}

private class Tile(val emoji: String, val title: String, val speech: String, val alt: Boolean, val fill: Int? = null, val action: () -> Unit)

private class Slide(val color: Int, val ink: Int, val emoji: String, val title: String, val text: String)

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    private fun <T : View> v(id: Int) = lazy { findViewById<T>(id) }
    private val root: View by v(R.id.root)
    private val bottomNav: View by v(R.id.bottomNav)
    private val splash: View by v(R.id.splash)
    private val home: View by v(R.id.home)
    private val camera: View by v(R.id.camera)
    private val listen: View by v(R.id.listen)
    private val previewView: PreviewView by v(R.id.preview)
    private val tvCamTitle: TextView by v(R.id.tvCamTitle)
    private val tvResult: TextView by v(R.id.tvResult)
    private val tvLive: TextView by v(R.id.tvLive)
    private val bMain: Button by v(R.id.bMain)
    private val bTorch: Button by v(R.id.bTorch)
    private val onboard: View by v(R.id.onboard)
    private val obBody: View by v(R.id.obBody)
    private val logo: View by v(R.id.logo)
    private val obEmoji: TextView by v(R.id.obEmoji)
    private val obTitle: TextView by v(R.id.obTitle)
    private val obText: TextView by v(R.id.obText)
    private val obDots: TextView by v(R.id.obDots)
    private val tvSkip: TextView by v(R.id.tvSkip)
    private val bNext: Button by v(R.id.bNext)

    private val yellow = Color.parseColor("#FFD400")
    private val navIds = listOf(R.id.nav0, R.id.nav1, R.id.nav2, R.id.nav3, R.id.nav4, R.id.nav5)
    private var page = 0
    private val slides = listOf(
        Slide(Color.parseColor("#FFD400"), Color.BLACK, "👁", "Mira con la voz", "Apunta la cámara y te describimos letreros, lugares y objetos."),
        Slide(Color.parseColor("#00E5FF"), Color.BLACK, "📖", "Entiende cualquier texto", "Menús y avisos explicados en lenguaje sencillo."),
        Slide(Color.parseColor("#7CFF6B"), Color.BLACK, "📡", "Guía en tiempo real", "Mientras caminas, te avisamos qué hay al frente."),
        Slide(Color.parseColor("#FF9F1C"), Color.BLACK, "🤟", "Señas a voz", "Haz tus señas frente a la cámara y las convertimos en texto y en voz."),
        Slide(Color.parseColor("#DD1367"), Color.WHITE, "🌍", "Ciudades para todos", "ODS 10: reducir las desigualdades. ODS 11: ciudades y comunidades sostenibles.")
    )
    private val swipe by lazy {
        GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (Math.abs(vx) > 800) { if (vx < 0) nextSlide() else prevSlide(); return true }
                return false
            }
        })
    }

    private lateinit var tts: TextToSpeech
    private var ttsReady = false
    private var pending: String? = null
    private val handler = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private val prefs by lazy { getSharedPreferences("guia", MODE_PRIVATE) }

    private var cameraProvider: ProcessCameraProvider? = null
    private var cam: Camera? = null
    private var imageCapture: ImageCapture? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var recording: Recording? = null
    private var recognizer: SpeechRecognizer? = null
    private var task = ""
    private var liveOn = false
    private var listening = false
    private var torchOn = false
    private var useFront = false
    private var signOn = false
    private val signLog = StringBuilder()
    private var lastSpoken = ""
    private var lastResult = ""
    private var lastErr = ""
    private var acc = ""
    private var afterPerm: (() -> Unit)? = null
    private var photoView: ImageView? = null

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        if (r.values.all { it }) afterPerm?.invoke()
        else { toast("Activa los permisos de cámara y micrófono en Ajustes del teléfono."); speak("Necesito permiso de cámara y micrófono.") }
    }

    private val prompts = mapOf(
        "describir" to "Eres un asistente para una persona ciega. Describe en español lo que hay en la imagen: primero lo más importante, luego detalles útiles (texto visible, personas, obstáculos, ubicación usando izquierda, derecha o frente). Máximo 6 frases cortas. Sin markdown ni símbolos.",
        "leer" to "Eres un asistente de lectura accesible. Lee el texto de la imagen (letrero, menú, aviso) y explícalo en español con lenguaje muy sencillo y frases cortas. Si es un menú, agrupa por tipo y menciona precios. Si hay una instrucción o peligro, dilo primero. Si no hay texto legible, dilo. Sin markdown ni símbolos.",
        "video" to "Describe en español, para una persona ciega o sorda, lo que ocurre en este video: escenas, personas, texto visible y lo que se dice en el audio (resúmelo en lenguaje sencillo). Máximo 8 frases cortas. Sin markdown ni símbolos.",
        "senas" to "Eres intérprete de Lengua de Señas Mexicana (LSM). En este video una persona se comunica con señas frente a la cámara. Traduce lo que dice a español natural, en una o dos frases cortas, como si lo dijera en voz alta en primera persona. Si deletrea con el alfabeto manual, une las letras en la palabra. Si no hay nadie haciendo señas, no se entienden o no estás seguro, responde únicamente la palabra NADA. No describas la escena, no expliques, no uses comillas ni símbolos."
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        setContentView(R.layout.activity_main)
        tts = TextToSpeech(this, this)

        navIds.forEach { findViewById<TextView>(it).textSize = 11f }
        click(R.id.bNext) { nextSlide() }
        click(R.id.tvSkip) { finishIntro() }
        onboard.setOnTouchListener { _, e -> swipe.onTouchEvent(e); true }
        click(R.id.nav0) { goHome() }
        click(R.id.nav1) { open("describir") }
        click(R.id.nav2) { open("leer") }
        click(R.id.nav3) { open("vivo") }
        click(R.id.nav4) { open("escuchar") }
        click(R.id.nav5) { open("senas") }
        buildHome()
        click(R.id.bRepetir) { speak(lastResult) }
        click(R.id.bTorch) { toggleTorch() }
        click(R.id.bBorrar) { acc = ""; tvLive.text = "" }
        click(R.id.bCopiar) { copyText() }
        bMain.setOnClickListener { vibrate(); onMain() }
        startIntro()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    onboard.visibility == View.VISIBLE -> if (page > 0) prevSlide() else show(home)
                    camera.visibility == View.VISIBLE || listen.visibility == View.VISIBLE -> goHome()
                    else -> finish()
                }
            }
        })
    }

    override fun onInit(status: Int) {
        if (status != TextToSpeech.SUCCESS) { toast("No se pudo iniciar la voz del teléfono."); return }
        val options = listOf(Locale("es", "MX"), Locale("es", "ES"), Locale("es"))
        val ok = options.any {
            val r = tts.setLanguage(it)
            r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
        }
        if (!ok) toast("Instala la voz en español: Ajustes > Idioma > Salida de texto a voz.")
        tts.setSpeechRate(prefs.getFloat("rate", 1f))
        ttsReady = true
        pending?.let { speak(it); pending = null }
    }

    override fun onDestroy() { stopAll(); tts.shutdown(); super.onDestroy() }
    override fun onStop() {
        stopAll()
        if (camera.visibility == View.VISIBLE || listen.visibility == View.VISIBLE) show(home)
        super.onStop()
    }

    /* ---------- Utilidades ---------- */
    private fun click(id: Int, f: () -> Unit) = findViewById<View>(id).setOnClickListener { vibrate(); f() }

    private fun show(s: View) {
        listOf(splash, onboard, home, camera, listen).forEach { it.visibility = if (it == s) View.VISIBLE else View.GONE }
        bottomNav.visibility = if (s == splash || s == onboard) View.GONE else View.VISIBLE
        if (s != splash && s != onboard) bars(Color.BLACK)
        if (s == home) setNav(0)
        if (s == camera || s == listen) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    private fun bars(c: Int) {
        window.statusBarColor = c
        window.navigationBarColor = c
        root.setBackgroundColor(c)
        val light = ColorUtils.calculateLuminance(c) > 0.5
        WindowCompat.getInsetsController(window, root).apply {
            isAppearanceLightStatusBars = light
            isAppearanceLightNavigationBars = light
        }
    }

    private fun setNav(sel: Int) {
        navIds.forEachIndexed { i, id ->
            val t = findViewById<TextView>(id)
            val on = i == sel
            t.setBackgroundColor(if (on) yellow else Color.BLACK)
            t.setTextColor(if (on) Color.BLACK else yellow)
        }
    }

    private fun toast(t: String) { Toast.makeText(this, t, Toast.LENGTH_LONG).show() }

    private fun speak(t: String, add: Boolean = false) {
        if (!ttsReady) { pending = t; return }
        tts.speak(t, if (add) TextToSpeech.QUEUE_ADD else TextToSpeech.QUEUE_FLUSH, null, "guia")
    }

    private fun vibrate() { (getSystemService(VIBRATOR_SERVICE) as Vibrator).vibrate(VibrationEffect.createOneShot(40, 255)) }
    private fun goHome() { stopAll(); show(home) }

    private fun withPerms(vararg p: String, ok: () -> Unit) {
        val missing = p.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) ok() else { afterPerm = ok; permLauncher.launch(missing.toTypedArray()) }
    }

    private fun stopAll() {
        hidePhoto()
        liveOn = false; listening = false; signOn = false
        handler.removeCallbacksAndMessages(null)
        try { recording?.stop() } catch (e: Exception) {}
        recording = null
        try { recognizer?.destroy() } catch (e: Exception) {}
        recognizer = null
        if (torchOn) { cam?.cameraControl?.enableTorch(false); torchOn = false }
        cameraProvider?.unbindAll()
        cam = null
        if (ttsReady) tts.stop()
    }

    private fun copyText() {
        if (acc.isBlank()) { toast("Aún no hay texto para copiar."); return }
        (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("transcripción", acc))
        toast("Texto copiado"); speak("Texto copiado")
    }

    /* ---------- Menú en cuadros ---------- */
    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()

    private fun box(fill: Int, stroke: Int, radius: Int, oval: Boolean = false) = GradientDrawable().apply {
        if (oval) shape = GradientDrawable.OVAL else cornerRadius = dp(radius).toFloat()
        setColor(fill); setStroke(dp(3), stroke)
    }

    private fun buildHome() {
        val grid = findViewById<LinearLayout>(R.id.grid)
        val full = resources.displayMetrics.widthPixels - dp(32)
        val side = (full - dp(12)) / 2

        val wide = Tile("🤟", "Señas a voz", "Señas a voz. Haz tus señas frente a la cámara y yo las traduzco a texto y las digo en voz alta.", false, Color.parseColor("#00E5FF")) { open("senas") }
        grid.addView(makeTile(wide), LinearLayout.LayoutParams(full, dp(150)).apply { setMargins(0, dp(6), 0, dp(6)) })

        val tiles = listOf(
            Tile("👁️", "Describir lo que veo", "Describir lo que veo. Toma una foto y te cuento qué hay: letreros, lugares y objetos.", false) { open("describir") },
            Tile("📖", "Leer en lenguaje sencillo", "Leer en lenguaje sencillo. Toma una foto de un menú o un aviso y te lo explico fácil.", false) { open("leer") },
            Tile("📡", "Guía en tiempo real", "Guía en tiempo real. Mientras caminas, te aviso qué hay al frente.", false) { open("vivo") },
            Tile("🎥", "Grabar video", "Grabar video. Grabo quince segundos y te cuento lo que pasó.", false) { open("video") },
            Tile("🎤", "Escuchar y transcribir", "Escuchar y transcribir. Convierto la voz de otras personas en texto grande.", false) { open("escuchar") },
            Tile("🗣️", "Decir un comando", "Decir un comando. Dime describir, leer, tiempo real, video o señas y abro esa función.", true) { voiceCommand() },
            Tile("🎞️", "Ver presentación", "Ver presentación. Repite la introducción de la aplicación.", true) { page = 0; renderSlide(false); show(onboard) },
            Tile("⚙️", "Ajustes de voz", "Ajustes de voz. Cambia qué tan rápido te hablo.", true) { voiceSettings() }
        )
        tiles.chunked(2).forEach { pair ->
            val row = LinearLayout(this)
            pair.forEachIndexed { i, t ->
                val lp = LinearLayout.LayoutParams(side, side).apply { setMargins(if (i == 0) 0 else dp(12), dp(6), 0, dp(6)) }
                row.addView(makeTile(t), lp)
            }
            grid.addView(row)
        }
    }

    private fun makeTile(t: Tile): View {
        val bg = t.fill ?: if (t.alt) Color.WHITE else yellow
        val f = FrameLayout(this).apply {
            background = box(bg, if (t.alt) yellow else Color.WHITE, 24)
            isClickable = true; isFocusable = true
            contentDescription = t.title
            setOnClickListener { vibrate(); t.action() }
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding(dp(6), dp(36), dp(6), dp(8))
        }
        col.addView(TextView(this).apply {
            text = t.emoji; textSize = 52f; gravity = Gravity.CENTER
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        })
        col.addView(TextView(this).apply {
            text = t.title; textSize = 16f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.BLACK); gravity = Gravity.CENTER
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        })
        f.addView(col, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        val sp = TextView(this).apply {
            text = "🔊"; textSize = 20f; gravity = Gravity.CENTER
            background = box(Color.BLACK, Color.WHITE, 0, true)
            isClickable = true
            contentDescription = "Escuchar descripción de ${t.title}"
            setOnClickListener { vibrate(); speak(t.speech) }
        }
        f.addView(sp, FrameLayout.LayoutParams(dp(48), dp(48), Gravity.TOP or Gravity.END).apply { setMargins(0, dp(8), dp(8), 0) })
        return f
    }

    private fun voiceSettings() {
        val names = arrayOf("Voz lenta", "Voz normal", "Voz rápida")
        val rates = floatArrayOf(0.75f, 1.0f, 1.4f)
        val cur = rates.indexOfFirst { it == prefs.getFloat("rate", 1f) }.let { if (it < 0) 1 else it }
        AlertDialog.Builder(this).setTitle("Velocidad de la voz")
            .setSingleChoiceItems(names, cur) { _, i ->
                prefs.edit().putFloat("rate", rates[i]).apply()
                tts.setSpeechRate(rates[i])
                speak("Así suena esta velocidad.")
            }
            .setPositiveButton("Listo", null).show()
    }

    /* ---------- Splash y presentación ---------- */
    private fun startIntro() {
        show(splash); bars(yellow)
        logo.alpha = 0f; logo.scaleX = 0.6f; logo.scaleY = 0.6f
        logo.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(700).start()
        handler.postDelayed({
            if (prefs.getBoolean("visto", false)) enterHome() else { page = 0; renderSlide(false); show(onboard) }
        }, 2300)
    }

    private fun enterHome() { show(home); speak("Guía accesible. Elige una opción o di un comando.") }

    private fun renderSlide(animate: Boolean) {
        val sl = slides[page]
        val draw = {
            bars(sl.color)
            onboard.setBackgroundColor(sl.color)
            obEmoji.text = sl.emoji; obTitle.text = sl.title; obText.text = sl.text
            listOf(obTitle, obText, tvSkip, obDots).forEach { it.setTextColor(sl.ink) }
            obDots.text = slides.indices.joinToString("  ") { if (it == page) "●" else "○" }
            obDots.contentDescription = "Pantalla ${page + 1} de ${slides.size}"
            bNext.text = if (page == slides.lastIndex) "Empezar" else "Siguiente"
            tvSkip.visibility = if (page == slides.lastIndex) View.INVISIBLE else View.VISIBLE
            speak(sl.title + ". " + sl.text)
        }
        if (!animate) { draw(); return }
        obBody.animate().alpha(0f).setDuration(120).withEndAction {
            draw(); obBody.animate().alpha(1f).setDuration(180).start()
        }.start()
    }

    private fun nextSlide() { if (page < slides.lastIndex) { page++; renderSlide(true) } else finishIntro() }
    private fun prevSlide() { if (page > 0) { page--; renderSlide(true) } }
    private fun finishIntro() { prefs.edit().putBoolean("visto", true).apply(); if (ttsReady) tts.stop(); enterHome() }

    /* ---------- Abrir funciones ---------- */
    private fun open(t: String) {
        stopAll()
        val navIndex = mapOf("describir" to 1, "leer" to 2, "vivo" to 3, "escuchar" to 4, "senas" to 5)[t] ?: -1
        if (t == "escuchar") {
            withPerms(Manifest.permission.RECORD_AUDIO) { show(listen); setNav(navIndex); startListening() }
            return
        }
        task = t
        useFront = (t == "senas")
        val perms = if (t == "video") arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO) else arrayOf(Manifest.permission.CAMERA)
        withPerms(*perms) {
            show(camera); setNav(navIndex)
            tvResult.text = ""
            tvCamTitle.text = mapOf("describir" to "Describir lo que veo", "leer" to "Leer en lenguaje sencillo", "vivo" to "Guía en tiempo real", "video" to "Grabar video", "senas" to "🤟 Señas a voz")[t]
            bMain.text = mapOf("vivo" to "▶ Iniciar guía", "video" to "⏺ Grabar 15 s", "senas" to "▶ Iniciar traducción")[t] ?: "📸 Tomar foto"
            bMain.isEnabled = true
            startCamera(t == "video" || t == "senas")
            speak(when (t) {
                "vivo" -> "Apunta al frente y toca iniciar guía."
                "video" -> "Toca grabar. Dura quince segundos."
                "senas" -> "Señas a voz. Toca iniciar y haz tus señas frente a la cámara."
                else -> "Apunta la cámara y toca tomar foto."
            })
        }
    }

    private fun onMain() {
        when (task) {
            "vivo" -> if (liveOn) stopLive() else startLive()
            "video" -> recordVideo()
            "senas" -> if (signOn) stopSigns() else startSigns()
            else -> {
                hidePhoto()
                bMain.isEnabled = false
                tvResult.text = "Analizando…"; speak("Analizando")
                capture(1280, save = true) { b64 -> gemini("image/jpeg", b64, prompts[task]!!) { ok, t -> showResult(ok, t) } }
            }
        }
    }

    private fun showResult(ok: Boolean, t: String) {
        bMain.isEnabled = true
        lastResult = t
        tvResult.text = t; speak(t)
    }

    /* ---------- Cámara (CameraX) ---------- */
    private fun startCamera(video: Boolean) {
        torchOn = false
        bTorch.text = if (task == "senas") "🔄 Cambiar cámara" else "🔦 Linterna"
        val f = ProcessCameraProvider.getInstance(this)
        f.addListener({
            try {
                val p = f.get(); cameraProvider = p
                val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
                imageCapture = ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY).build()
                val qs = QualitySelector.from(Quality.SD, FallbackStrategy.lowerQualityOrHigherThan(Quality.SD))
                videoCapture = VideoCapture.withOutput(Recorder.Builder().setQualitySelector(qs).build())
                val hasBack = p.hasCamera(CameraSelector.DEFAULT_BACK_CAMERA)
                val hasFront = p.hasCamera(CameraSelector.DEFAULT_FRONT_CAMERA)
                val sel = if (useFront && hasFront) CameraSelector.DEFAULT_FRONT_CAMERA
                else if (hasBack) CameraSelector.DEFAULT_BACK_CAMERA else CameraSelector.DEFAULT_FRONT_CAMERA
                p.unbindAll()
                cam = if (video) p.bindToLifecycle(this, sel, preview, videoCapture)
                else p.bindToLifecycle(this, sel, preview, imageCapture)
            } catch (e: Exception) {
                Log.e("Camara", "fallo", e)
                toast("Cámara: ${e.javaClass.simpleName} - ${e.message}"); speak("No pude abrir la cámara.")
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun toggleTorch() {
        if (task == "senas") {
            if (signOn) { toast("Detén la traducción para cambiar de cámara."); return }
            useFront = !useFront
            startCamera(true)
            return
        }
        val c = cam
        if (c == null) { toast("La cámara aún no está lista."); return }
        if (!c.cameraInfo.hasFlashUnit()) { toast("Este teléfono no tiene linterna en la cámara."); return }
        torchOn = !torchOn
        c.cameraControl.enableTorch(torchOn)
        bTorch.text = if (torchOn) "🔦 Apagar" else "🔦 Linterna"
    }

    private fun capture(max: Int, save: Boolean = false, done: (String) -> Unit) {
        val ic = imageCapture
        if (ic == null) { toast("La cámara aún no está lista."); bMain.isEnabled = true; return }
        ic.takePicture(ContextCompat.getMainExecutor(this), object : ImageCapture.OnImageCapturedCallback() {
            override fun onCaptureSuccess(image: ImageProxy) {
                val bmp = image.toBitmap(); val rot = image.imageInfo.rotationDegrees; image.close()
                val s = minOf(1f, max.toFloat() / maxOf(bmp.width, bmp.height))
                val m = Matrix().apply { postRotate(rot.toFloat()); postScale(s, s) }
                val out = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
                if (save) { savePhoto(out); showPhoto(out) }
                val bos = ByteArrayOutputStream(); out.compress(Bitmap.CompressFormat.JPEG, 80, bos)
                done(Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP))
            }
            override fun onError(e: ImageCaptureException) {
                toast("No pude tomar la foto."); bMain.isEnabled = true
                if (liveOn) handler.postDelayed({ liveStep() }, 3000)
            }
        })
    }

    /* ---------- Gemini ---------- */
    private fun gemini(mime: String, b64: String, prompt: String, cb: (Boolean, String) -> Unit) {
        val key = Secrets.GEMINI_API_KEY.trim()
        if (key.isBlank() || key.startsWith("PEGA") || key.startsWith("TU_CLAVE")) {
            cb(false, "Falta configurar la clave de Gemini en el código de la app."); return
        }
        io.execute {
            var ok = false
            var out = "No pude analizar."
            try {
                val parts = JSONArray()
                    .put(JSONObject().put("inline_data", JSONObject().put("mime_type", mime).put("data", b64)))
                    .put(JSONObject().put("text", prompt))
                val body = JSONObject().put("contents", JSONArray().put(JSONObject().put("parts", parts)))
                loop@ for (model in Secrets.MODELS) {
                    for (attempt in 1..2) {
                        val c = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent").openConnection() as HttpURLConnection
                        c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 20000; c.readTimeout = 60000
                        c.setRequestProperty("Content-Type", "application/json"); c.setRequestProperty("x-goog-api-key", key)
                        c.outputStream.use { it.write(body.toString().toByteArray()) }
                        val code = c.responseCode
                        if (code in 200..299) {
                            val txt = c.inputStream.bufferedReader().readText()
                            val text = JSONObject(txt).optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")
                                ?.optJSONArray("parts")?.optJSONObject(0)?.optString("text", "")
                                ?.replace(Regex("[*#_`]"), "")?.trim() ?: ""
                            if (text.isNotEmpty()) { ok = true; out = text } else out = "No obtuve respuesta. Intenta con otra foto."
                            break@loop
                        }
                        val err = c.errorStream?.bufferedReader()?.readText() ?: ""
                        val detail = try { JSONObject(err).getJSONObject("error").getString("message") } catch (e: Exception) { err }.take(140)
                        Log.e("Gemini", "$model intento $attempt -> $code $err")
                        if (code == 401 || code == 403 || (code == 400 && detail.contains("API key", true))) {
                            out = "La clave de Gemini no es válida o no tiene permiso (error $code)."
                            break@loop
                        }
                        out = when (code) {
                            404 -> "El modelo $model no está disponible (error 404)."
                            429 -> "Se alcanzó el límite de uso. Espera un minuto e intenta de nuevo."
                            in 500..599 -> "El servicio de IA no está disponible (error $code). $detail"
                            else -> "No pude analizar (error $code). $detail"
                        }
                        if (code in 500..599 && attempt == 1) { Thread.sleep(1500); continue }
                        break
                    }
                }
            } catch (e: UnknownHostException) {
                out = "No hay conexión a internet."
            } catch (e: SocketTimeoutException) {
                out = "La conexión tardó demasiado. Intenta de nuevo."
            } catch (e: Exception) {
                Log.e("Gemini", "fallo", e)
                out = "No pude analizar: ${e.javaClass.simpleName}"
            }
            runOnUiThread { cb(ok, out) }
        }
    }

    /* ---------- Guía en tiempo real ---------- */
    private fun livePrompt() = "Estás guiando en tiempo real a una persona ciega que camina. Di en una o dos frases cortas lo más importante frente a ella (obstáculos, puertas, escaleras, letreros, personas) indicando izquierda, derecha o frente. Lo último que dijiste fue: \"$lastSpoken\". Si no hay cambios relevantes, responde solo la palabra IGUAL. Sin markdown."

    private fun startLive() { liveOn = true; lastSpoken = ""; lastErr = ""; bMain.text = "⏹ Detener guía"; tvResult.text = "Mirando…"; liveStep() }
    private fun stopLive() { liveOn = false; handler.removeCallbacksAndMessages(null); bMain.text = "▶ Iniciar guía"; if (ttsReady) tts.stop() }

    private fun liveStep() {
        if (!liveOn) return
        capture(800) { b64 ->
            gemini("image/jpeg", b64, livePrompt()) { ok, t ->
                if (!liveOn) return@gemini
                var wait = 6000L
                if (!ok) {
                    tvResult.text = t; wait = 12000L
                    if (t != lastErr) { lastErr = t; speak(t) }
                } else if (!t.startsWith("IGUAL", true)) {
                    lastErr = ""; lastSpoken = t; lastResult = t; tvResult.text = t; speak(t)
                    wait += minOf(t.length * 60L, 6000L)
                }
                handler.postDelayed({ liveStep() }, wait)
            }
        }
    }

    /* ---------- Señas a voz ---------- */
    private fun startSigns() {
        if (videoCapture == null) { toast("La cámara aún no está lista."); return }
        signOn = true; lastErr = ""; signLog.setLength(0)
        bMain.text = "⏹ Detener traducción"
        tvResult.text = "Haz tus señas frente a la cámara…"
        speak("Listo. Haz tus señas frente a la cámara.")
        signClip()
    }

    private fun stopSigns() {
        signOn = false
        handler.removeCallbacksAndMessages(null)
        try { recording?.stop() } catch (e: Exception) {}
        bMain.text = "▶ Iniciar traducción"
        tvCamTitle.text = "🤟 Señas a voz"
    }

    @SuppressLint("MissingPermission")
    private fun signClip() {
        if (!signOn) return
        val vc = videoCapture
        if (vc == null) { stopSigns(); toast("La cámara aún no está lista."); return }
        val file = File(cacheDir, "sena-${System.currentTimeMillis()}.mp4")
        tvCamTitle.text = "🤟 Señas a voz  ● grabando"
        recording = vc.output.prepareRecording(this, FileOutputOptions.Builder(file).build())
            .start(ContextCompat.getMainExecutor(this)) { ev ->
                if (ev is VideoRecordEvent.Finalize) {
                    recording = null
                    if (!signOn) { file.delete(); return@start }
                    if (ev.hasError()) {
                        file.delete()
                        handler.postDelayed({ signClip() }, 1500)
                    } else {
                        analyzeSign(file)
                        signClip()
                    }
                }
            }
        handler.postDelayed({ recording?.stop() }, 7000)
    }

    private fun analyzeSign(file: File) {
        io.execute {
            val b64 = Base64.encodeToString(file.readBytes(), Base64.NO_WRAP)
            file.delete()
            runOnUiThread {
                gemini("video/mp4", b64, prompts["senas"]!!) { ok, t ->
                    if (!signOn) return@gemini
                    if (!ok) {
                        if (t != lastErr) { lastErr = t; tvResult.text = t; speak(t, true) }
                        return@gemini
                    }
                    lastErr = ""
                    val s = t.trim()
                    if (s.isEmpty() || s.startsWith("NADA", true)) return@gemini
                    signLog.append(s).append("\n\n")
                    tvResult.text = signLog.toString()
                    lastResult = s
                    speak(s, true)
                }
            }
        }
    }

    /* ---------- Grabar video ---------- */
    @SuppressLint("MissingPermission")
    private fun recordVideo() {
        val vc = videoCapture
        if (vc == null) { toast("La cámara aún no está lista."); return }
        val file = File(cacheDir, "clip.mp4"); if (file.exists()) file.delete()
        bMain.isEnabled = false; tvResult.text = "● Grabando… 15 segundos"; speak("Grabando")
        val opts = FileOutputOptions.Builder(file).build()
        recording = vc.output.prepareRecording(this, opts).withAudioEnabled()
            .start(ContextCompat.getMainExecutor(this)) { ev ->
                if (ev is VideoRecordEvent.Finalize) {
                    recording = null
                    if (!ev.hasError()) sendVideo(file) else { bMain.isEnabled = true; tvResult.text = "No pude grabar el video." }
                }
            }
        handler.postDelayed({ recording?.stop() }, 15000)
    }

    private fun sendVideo(file: File) {
        saveToGallery(file)
        tvResult.text = "Analizando video…"; speak("Analizando video")
        io.execute {
            val b64 = Base64.encodeToString(file.readBytes(), Base64.NO_WRAP)
            runOnUiThread { gemini("video/mp4", b64, prompts["video"]!!) { ok, t -> showResult(ok, t) } }
        }
    }

    private fun saveToGallery(file: File) {
        try {
            val cv = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, "guia-${System.currentTimeMillis()}.mp4")
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/GuiaAccesible")
            }
            contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv)?.let { uri ->
                contentResolver.openOutputStream(uri)?.use { o -> file.inputStream().use { it.copyTo(o) } }
                toast("Video guardado en Películas")
            }
        } catch (e: Exception) { Log.e("Video", "no se pudo guardar", e) }
    }

    private fun showPhoto(bmp: Bitmap) {
        hidePhoto()
        val iv = ImageView(this).apply {
            setImageBitmap(bmp)
            scaleType = ImageView.ScaleType.FIT_CENTER
            setBackgroundColor(Color.BLACK)
            contentDescription = "Foto tomada"
        }
        previewView.addView(iv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        photoView = iv
    }

    private fun hidePhoto() {
        photoView?.let { previewView.removeView(it) }
        photoView = null
    }

    private fun savePhoto(bmp: Bitmap) {
        try {
            val cv = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, "guia-${System.currentTimeMillis()}.jpg")
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/GuiaAccesible")
            }
            contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)?.let { uri ->
                contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }
                toast("Foto guardada en Imágenes")
            }
        } catch (e: Exception) { Log.e("Foto", "no se pudo guardar", e) }
    }

    /* ---------- Voz a texto ---------- */
    private fun srIntent() = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-MX")
        .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)

    private fun first(b: Bundle?) = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""

    private fun srError(code: Int): String? = when (code) {
        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Sin internet para transcribir."
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Permite el micrófono en los ajustes del teléfono."
        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "El reconocimiento de voz está ocupado. Espera un momento."
        else -> null
    }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            tvLive.text = "Tu teléfono no tiene reconocimiento de voz. Instala o activa la app Google."
            return
        }
        listening = true; acc = ""; tvLive.text = "Habla cerca del teléfono."
        val r = SpeechRecognizer.createSpeechRecognizer(this); recognizer = r
        r.setRecognitionListener(object : SimpleListener() {
            override fun onPartialResults(p: Bundle?) {
                val x = first(p); if (x.isNotEmpty()) tvLive.text = (acc + " " + x).trim()
            }
            override fun onResults(p: Bundle?) {
                val x = first(p)
                if (x.isNotEmpty()) { acc = (acc + " " + x).trim(); tvLive.text = acc }
                if (listening) r.startListening(srIntent())
            }
            override fun onError(p: Int) {
                srError(p)?.let { tvLive.text = if (acc.isEmpty()) it else "$acc\n($it)" }
                if (listening && p != SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                    val delay = if (srError(p) != null) 1500L else 300L
                    handler.postDelayed({ if (listening) r.startListening(srIntent()) }, delay)
                }
            }
        })
        r.startListening(srIntent())
    }

    /* ---------- Comandos de voz ---------- */
    private fun voiceCommand() {
        withPerms(Manifest.permission.RECORD_AUDIO) {
            speak("Te escucho")
            handler.postDelayed({
                val r = SpeechRecognizer.createSpeechRecognizer(this)
                r.setRecognitionListener(object : SimpleListener() {
                    override fun onResults(p: Bundle?) { r.destroy(); runCommand(first(p).lowercase()) }
                    override fun onError(p: Int) { r.destroy(); toast(srError(p) ?: "No te escuché"); speak("No te escuché") }
                })
                r.startListening(srIntent())
            }, 1500)
        }
    }

    private fun runCommand(t: String) {
        toast("Escuché: $t")
        when {
            Regex("se[ñn]as|se[ñn]a|sordo|mudo").containsMatchIn(t) -> open("senas")
            Regex("tiempo real|en vivo|gu[ií]a|caminar").containsMatchIn(t) -> open("vivo")
            Regex("v[ií]deo|grab").containsMatchIn(t) -> open("video")
            Regex("describ|qué hay").containsMatchIn(t) -> open("describir")
            Regex("le[eé]r|lee|texto|menú").containsMatchIn(t) -> open("leer")
            Regex("escuch|transcrib|hablar").containsMatchIn(t) -> open("escuchar")
            Regex("ajust|velocidad").containsMatchIn(t) -> voiceSettings()
            Regex("inicio|volver|atrás").containsMatchIn(t) -> goHome()
            else -> speak("No entendí. Prueba con describir, leer, tiempo real, video o señas.")
        }
    }
}