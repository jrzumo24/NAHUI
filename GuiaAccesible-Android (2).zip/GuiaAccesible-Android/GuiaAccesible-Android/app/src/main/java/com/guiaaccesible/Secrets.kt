package com.guiaaccesible

object Secrets {
    // Pega aquí tu clave de Gemini, entre las comillas.
    const val GEMINI_API_KEY = "AQ.Ab8RN6KbIunlfmTfy7lqAL0zUWVg-SnZCZWOjIS2XFiUMwGTiw"

    // Se prueban en orden. Si el primero no existe, usa el siguiente.
    val MODELS = listOf("gemini-2.5-flash", "gemini-3.8-flash")
}